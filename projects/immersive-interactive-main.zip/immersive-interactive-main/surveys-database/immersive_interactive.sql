--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Ubuntu 17.5-1.pgdg22.04+1)
-- Dumped by pg_dump version 17.5 (Ubuntu 17.5-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: survey_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.survey_answers (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    survey_uuid uuid NOT NULL,
    answer json NOT NULL
);


ALTER TABLE public.survey_answers OWNER TO postgres;

--
-- Name: survey_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.survey_answers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.survey_answers_id_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1
);


--
-- Name: survey_questions; Type: TABLE; Schema: public; Owner: petermcc
--

CREATE TABLE public.survey_questions (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    survey_uuid uuid NOT NULL,
    type character varying NOT NULL,
    name character varying NOT NULL,
    label character varying NOT NULL,
    validation_schema json NOT NULL
);


ALTER TABLE public.survey_questions OWNER TO petermcc;

--
-- Name: survey_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: petermcc
--

ALTER TABLE public.survey_questions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.survey_questions_id_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1
);


--
-- Name: surveys; Type: TABLE; Schema: public; Owner: petermcc
--

CREATE TABLE public.surveys (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL
);


ALTER TABLE public.surveys OWNER TO petermcc;

--
-- Name: surveys_id_seq; Type: SEQUENCE; Schema: public; Owner: petermcc
--

ALTER TABLE public.surveys ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.surveys_id_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: survey_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.survey_answers (id, uuid, survey_uuid, answer) FROM stdin;
\.


--
-- Data for Name: survey_questions; Type: TABLE DATA; Schema: public; Owner: petermcc
--

COPY public.survey_questions (id, uuid, survey_uuid, type, name, label, validation_schema) FROM stdin;
1	8348bb04-8738-4bfa-b7f3-b3324462ead3	6ea68b22-f2f2-4256-8ebb-61b32fd0d686	multiple_choice	referral	How did you hear about us?	{"type":"string","flags":{"only":true,"presence":"required"},"allow":["Friends","Online Ad","Social Media","Other"]}
2	5e5500f5-6de1-4fd0-a9b4-8a149d791220	6ea68b22-f2f2-4256-8ebb-61b32fd0d686	rating	rating	Rate our service	{"type":"number","flags":{"presence":"required"},"rules":[{"name":"integer"},{"name":"min","args":{"limit":1}},{"name":"max","args":{"limit":5}}]}
0	1cf8a34d-ce17-4d18-bf22-68a57c4e64c8	6ea68b22-f2f2-4256-8ebb-61b32fd0d686	text	name	What is your name?	{"type":"string","flags":{"presence":"required"},"rules":[{"name":"min","args":{"limit":3}},{"name":"max","args":{"limit":30}}]}
\.


--
-- Data for Name: surveys; Type: TABLE DATA; Schema: public; Owner: petermcc
--

COPY public.surveys (id, uuid, title, description) FROM stdin;
0	6ea68b22-f2f2-4256-8ebb-61b32fd0d686	Customer Satisfaction Survey	Description of survey.
\.


--
-- Name: survey_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.survey_answers_id_seq', 13, true);


--
-- Name: survey_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: petermcc
--

SELECT pg_catalog.setval('public.survey_questions_id_seq', 0, false);


--
-- Name: surveys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: petermcc
--

SELECT pg_catalog.setval('public.surveys_id_seq', 0, false);


--
-- Name: survey_answers survey_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.survey_answers
    ADD CONSTRAINT survey_answers_pkey PRIMARY KEY (id);


--
-- Name: survey_questions survey_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: petermcc
--

ALTER TABLE ONLY public.survey_questions
    ADD CONSTRAINT survey_questions_pkey PRIMARY KEY (id);


--
-- Name: surveys surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: petermcc
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_pkey PRIMARY KEY (id);


--
-- Name: survey_answers_uuid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX survey_answers_uuid ON public.survey_answers USING btree (uuid);


--
-- Name: survey_questions_uuid; Type: INDEX; Schema: public; Owner: petermcc
--

CREATE INDEX survey_questions_uuid ON public.survey_questions USING btree (uuid);


--
-- Name: surveys_uuid; Type: INDEX; Schema: public; Owner: petermcc
--

CREATE INDEX surveys_uuid ON public.surveys USING btree (uuid);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

