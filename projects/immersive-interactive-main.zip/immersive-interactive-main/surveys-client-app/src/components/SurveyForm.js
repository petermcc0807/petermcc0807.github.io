//
// TODO [1] : Add code to validate value when changed
//
// NOTE [1] : Assuming 'rules' array indexes for min and max values
//

import React, { useEffect } from 'react';

import { useSelector, useDispatch } from 'react-redux';
import { updateSurveyAnswers, fetchSurvey } from '../state/surveySlice';

import axios from 'axios';

const SurveyForm = () => {
  const dispatch = useDispatch();

  const survey = useSelector((state) => state.survey.data);
  const surveyExtra = useSelector((state) => state.survey.extraData);
  const surveyStatus = useSelector((state) => state.survey.status);

  const error = useSelector((state) => state.survey.error);

  useEffect(() =>
  {
    if (surveyStatus === 'idle')
      dispatch(fetchSurvey());
  }, [ surveyStatus, dispatch ]);

  const handleValueChange = (event) =>
  {
    // TODO: see [1]

    const name = event.target.name;

    let value;

    if (name === 'rating')
      value = parseInt(event.target.value, 10);
    else
      value = event.target.value;

    const payload = { name, value };

    dispatch(updateSurveyAnswers(payload));
  };

  const handleSubmit = async (event) =>
  {
    event.preventDefault();

    try
    {
      let data =
      {
        uuid: survey.uuid,

        answers: [ ]
      };

      survey.questions.forEach((question) =>
      {
        if (surveyExtra.answers[question.name] !== undefined)
        {
          const answer =
          {
            questionUuid: question.uuid,

            name: question.name,
            value: surveyExtra.answers[question.name]
          };

          answer.questionUuid = question.uuid;

          data.answers.push(answer);
        }
      });

      const response = await axios.post('http://localhost:10240/survey', data);

      if (response.status === 200)
      {
        data = response.data;

        if (data.error === false)
        {
          // Do something
        }
        else
        {
          // Do something
        }
      }
      else
      {
        // Do something
      }
    }

    catch (exception)
    {
      // Do something
    }
  };

  const renderQuestion = (question) =>
  {
    switch (question.type)
    {
      case 'text':
        return <input type="text" name={ question.name } onChange={ handleValueChange } />;

      case 'multiple_choice':
        return (
          <select name={ question.name } onChange={ handleValueChange }>
            <option value="">--Please choose an option--</option>
            {
              question.validation_schema.allow.map((option) => (
                <option key={ option } value={ option }>{ option }</option>
              ))
            }
          </select>
        );

      case 'rating':
        // NOTE: see [1]

        return <input type="number"
                      name={ question.name }
                      min={ question.validation_schema.rules[1].args.limit }
                      max={ question.validation_schema.rules[2].args.limit }
                      onKeyDown={ (event) => { event.preventDefault(); } }
                      onChange={ handleValueChange } />;

      default:
        return <p>Unsupported question type</p>;
    }
  };

  if (surveyStatus === 'loading')
  {
    return <div>Loading survey...</div>;
  }

  if (surveyStatus === 'failed')
  {
    return <div>Could not load survey: { error }</div>;
  }

  if (surveyStatus === 'succeeded' && survey)
  {
    return (
      <form onSubmit={ handleSubmit }>
        <h1>{ survey.title }</h1>
        <p>{ survey.description }</p>
        <hr />
        {
          survey.questions.map((question) => (
            <div key={ question.uuid } className="question">
              <label>{ question.label }</label>
              { renderQuestion(question) }
            </div>
          ))
        }
        <button type="submit">Submit</button>
      </form>
    );
  }

  return null;
};

export default SurveyForm;
