import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

import axios from 'axios';

export const fetchSurvey = createAsyncThunk('survey/fetchSurvey', async () =>
{
  let survey = { };

  try
  {
    const response = await axios.get('http://localhost:10240/survey');

    survey = response.data.survey;
  }

  catch (exception)
  {
    // Do something
  }

  return survey;
});

const surveySlice = createSlice({
  name: 'survey',

  initialState:
  {
    data: null,
    extraData: null,

    status: 'idle',

    error: null
  },

  reducers:
  {
    updateSurveyAnswers(state, action)
    {
      state.extraData.answers[action.payload.name] = action.payload.value;
    }
  },

  extraReducers: (builder) =>
  {
    builder.addCase(fetchSurvey.pending, (state) =>
    {
      state.status = 'loading';
    })
    .addCase(fetchSurvey.fulfilled, (state, action) =>
    {
      const data = action.payload;

      state.data = data;

      const extraData = { answers: { } };

      state.extraData = extraData;

      state.status = 'succeeded';
    })
    .addCase(fetchSurvey.rejected, (state, action) =>
    {
      state.status = 'failed';

      state.error = action.error.message;
    });
  }
});

export const { updateSurveyAnswers } = surveySlice.actions

export default surveySlice.reducer;
