'use strict';

const { EntitySchema } = require('typeorm');

const SurveySchema = new EntitySchema({
    name: 'Survey',

    tableName: 'surveys',

    columns:
    {
        id:
        {
            type: 'int',
            generated: true,
            primary: true
        },

        uuid:
        {
            type: 'uuid',
            unique: true
        },

        title:
        {
            type: 'varchar'
        },
        
        description:
        {
            type: 'varchar'
        }
    }
});

module.exports = { SurveySchema };
