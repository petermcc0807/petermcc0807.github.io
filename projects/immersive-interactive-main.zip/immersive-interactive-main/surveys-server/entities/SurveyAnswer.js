'use strict';

const { EntitySchema } = require('typeorm');

const SurveyAnswerSchema = new EntitySchema({
    name: 'SurveyAnswer',

    tableName: 'survey_answers',

    columns:
    {
        id:
        {
            type: 'int',
            generated: true,
            primary: true
        },

        uuid:
        {
            type: 'uuid',
            unique: true
        },

        survey_uuid:
        {
            type: 'uuid'
        },

        answer:
        {
            type: 'json'
        }
    }
});

module.exports = { SurveyAnswerSchema };
