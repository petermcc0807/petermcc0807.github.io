'use strict';

const { EntitySchema } = require('typeorm');

const SurveyQuestionSchema = new EntitySchema({
    name: 'SurveyQuestion',

    tableName: "survey_questions",

    columns:
    {
        id:
        {
            type: 'int',
            generated: true,
            primary: true
        },

        uuid:
        {
            type: 'uuid',
            unique: true
        },
        
        survey_uuid:
        {
            type: 'uuid'
        },
        
        type:
        {
            type: 'varchar'
        },
        
        name:
        {
            type: 'varchar'
        },
        
        label:
        {
            type: 'varchar',
        },
        
        validation_schema:
        {
            type: 'json'
        }
    }
});

module.exports = { SurveyQuestionSchema };
