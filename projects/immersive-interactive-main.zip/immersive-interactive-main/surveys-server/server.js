'use strict';

const Fs = require('fs');
const Http = require('http');
const Readline = require('readline');

require('reflect-metadata'); const { DataSource } = require('typeorm');

const { SurveySchema } = require('./entities/Survey');
const { SurveyQuestionSchema } = require('./entities/SurveyQuestion');
const { SurveyAnswerSchema } = require('./entities/SurveyAnswer');

const Uuid = require('uuid');

const Express = require('express');
const Cors = require('cors');
const Nocache = require('nocache');

const joi = require('joi');

const KEY_EXIT = 'x';

console.log('Loading configuration...');

let configuration = Fs.readFileSync('configuration.json', { encoding: 'utf8' });

configuration = JSON.parse(configuration);

console.log('configuration loaded');

const main = async () =>
{
    // Configure and initialise data source

    const dataSourceConfiguration = configuration.dataSource;

    dataSourceConfiguration.entities = [ SurveySchema, SurveyQuestionSchema, SurveyAnswerSchema ];

    const dataSource = new DataSource(dataSourceConfiguration);

    await dataSource.initialize();

    // Configure and start HTTP (API) server

    const express = Express();

    const json = Express.json();

    express.use(json);

    const nocache = Nocache();

    express.use(nocache);

    const cors = Cors();

    express.use(cors);

    express.use((request, response, next) =>
    {
        console.log(`express.use(): request.url=${ request.url }`);

        next();
    });

    express.get('/survey', async (request, response) =>
    {
        console.log('express.get(/survey)');

        let code; let data;

        // Select survey title, description and questions from data source

        try
        {
            const surveyRepository = dataSource.getRepository('Survey');

            let options =
            {
                order: { id: 'DESC' },
                take: 1
            };

            const survey = (await surveyRepository.find(options))[0];

            delete survey.id;

            const surveyQuestionRepository = dataSource.getRepository('SurveyQuestion');

            options =
            {
                order: { id: 'ASC' },
                where: { survey_uuid: survey.uuid }
            };

            const surveyQuestions = await surveyQuestionRepository.find(options);

            surveyQuestions.forEach((surveyQuestion) =>
            {
                delete surveyQuestion.id;
                delete surveyQuestion.survey_uuid;
            });

            code = 200;

            data =
            {
                error: false,

                survey:
                {
                    ...survey,

                    questions: surveyQuestions
                }
            };
        }

        catch (error)
        {
            code = 500;

            data = { error: true };
        }

        // Send response

        response.status(code).json(data);
    });

    express.post('/survey', async (request, response) =>
    {
        console.log('express.post(/survey)');

        let code; let data;

        // Validate survey answers and insert answers into data source

        try
        {
            // Validate survey answers

            const surveyQuestionRepository = dataSource.getRepository('SurveyQuestion');

            const options =
            {
                order: { id: 'ASC' },

                where: { survey_uuid: request.body.uuid }
            };

            const surveyQuestions = await surveyQuestionRepository.find(options);

            const schemaToBuild =
            {
                type: 'object',

                keys: { }
            };

            surveyQuestions.forEach((surveyQuestion) => { schemaToBuild.keys[surveyQuestion.name] = surveyQuestion.validation_schema; });

            const schema = joi.build(schemaToBuild);

            const answerData = { };

            request.body.answers.forEach((answer) => { answerData[answer.name] = answer.value; });

            const { error, value } = schema.validate(answerData);

            // Insert survey answers into data source

            if (error === undefined)
            {
                const surveyAnswerRepository = dataSource.getRepository('SurveyAnswer');

                const surveyAnswer =
                {
                    uuid: Uuid.v4(),

                    survey_uuid: request.body.uuid,

                    answer: value
                };

                await surveyAnswerRepository.save(surveyAnswer);

                code = 200;

                data = { error: false };
            }
            else
            {
                code = 200;

                data = { error: true };
            }
        }

        catch (error)
        {
            code = 500;

            data = { error: true };
        }

        // Send response

        response.status(code).json(data);
    });

    const appPath = `${ __dirname }/${ configuration.paths.app }`;

    express.use('/app', Express.static(appPath));

    console.log('main(): Starting HTTP server...');

    const httpServer = Http.createServer(express);

    const httpServerConfiguration = configuration.httpServer;

    httpServer.listen(httpServerConfiguration.port, httpServerConfiguration.host, () =>
    {
        console.log(`httpServer.listen(): HTTP server started and listening on http://${ httpServerConfiguration.host }:${ httpServerConfiguration.port }`);

        // Do something
    });

    // Initialise stdin reader and handle keypress events (e.g. 'x' to exit)

    Readline.emitKeypressEvents(process.stdin);

    if (process.stdin.isTTY === true)
        process.stdin.setRawMode(true);

    process.stdin.on('keypress', async (characters, key) =>
    {
        if ((key !== undefined) && (key !== null))
        {
            if (key.name === KEY_EXIT)
            {
                console.log('process.stdin.on(keypress): Closing HTTP server connections...');

                httpServer.closeAllConnections();

                console.log('process.stdin.on(keypress): HTTP server connections closed');

                process.exit();
            }
        }
    });
};

main();
