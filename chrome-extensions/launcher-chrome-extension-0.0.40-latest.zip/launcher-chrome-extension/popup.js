'use strict';

const main = () =>
{
    const configureButton = document.getElementById('ConfigureButton');

    configureButton.addEventListener('click', () =>
    {
        window.open('page.html', '_blank');
    });
};

main();
