//
// NOTE [1] : When using Sony controller (for example) on Linux, need to grant
//            access permissions. First, identify device:
//
//              $ ls -la /dev/hidraw*
//
//            Say device is /dev/hidraw3, grant permissions:
//
//              $ sudo chmod 666 /dev/hidraw3
//

'use strict';

// AP10 HID
const USAGE_PAGE = 0xFFB0;
const USAGE = 0x000F;
// AP10 HID

const main = () =>
{
    const connectButton = document.getElementById('ConnectButton');

    connectButton.addEventListener('click', async () =>
    {
        try
        {
            // AP10 HID
            const filters =
            [
                { vendorId: 0x0D48, productId: 0x0019 }, // AP10 Standard
                { vendorId: 0x0D48, productId: 0x001A } // AP10 Premium
            ];
            // AP10 HID

            // Test HID
            /* // const filters = [ { vendorId: 0x1C59, productId: 0x0023 } ]; // C64 joystick
            const filters = [ { vendorId: 0x054C, productId: 0x0CE6 } ]; // Sony controller */
            // Test HID

            const options = { filters };

            const devices = await navigator.hid.requestDevice(options);

            // AP10
            let deviceIndex;

            let index = 0; const index1 = devices.length; let index2; let index3;

            let device; let collections; let collection;

            while ((deviceIndex === undefined) && (index < index1))
            {
                device = devices[index];

                collections = device.collections;

                index2 = 0;
                index3 = collections.length;

                while ((deviceIndex === undefined) && (index2 < index3))
                {
                    collection = collections[index2];

                    if ((collection.usagePage === USAGE_PAGE) && (collection.usage === USAGE))
                        deviceIndex = index;
                    else
                        ++index2;
                }

                if (deviceIndex === undefined)
                    ++index;
            }

            if (deviceIndex !== undefined)
            {
                if (chrome.runtime !== undefined)
                {
                    const response = await chrome.runtime.sendMessage({ sender: 'page', type: 'openDevice', data: { index: deviceIndex } });

                    console.log(`chrome.runtime.sendMessage(): sender=${ response.sender }, type=${ response.type }`);

                    // Do something
                }
            }
            // AP10

            // Test HID
            /* if (devices.length === 1)
            {
                if (chrome.runtime !== undefined)
                {
                    const response = await chrome.runtime.sendMessage({ sender: 'page', type: 'openDevice', data: { index: 0 } });

                    console.log(`chrome.runtime.sendMessage(): sender=${ response.sender }, type=${ response.type }`);

                    // Do something
                }
            } */
            // Test HID
        }

        catch (exception) { }
    });
};

main();
