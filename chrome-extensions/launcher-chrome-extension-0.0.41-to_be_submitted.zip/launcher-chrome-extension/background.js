//
// TODO [1] : Implement chrome.windows.onFocusChanged()
//
// NOTE [1] : https://developer.chrome.com/docs/extensions/develop/concepts/messaging
//            https://stackoverflow.com/questions/44056271/chrome-runtime-onmessage-response-with-async-await (see first answer)
//

'use strict';

// NEW (0.0.41)
const TIMER_INTERVAL = 2500;
const CHROMEOSANDROIDBRIDGE_TIMEOUT = 2500;

const ALARM_FREQUENCY_SECONDS = 30.0;
// NEW (0.0.41)

// Test HID
/* const BUTTONS =
{
    // C64 joystick

    // byteIndex: 5,
    //
    // byteValues:
    // {
    //     none: 0x0f,
    //     toggleState: 0x1f,
    //     close: 0x2f
    // }

    // Sony controller

    byteIndex: 7,

    byteValues:
    {
        none: 0x08,
        toggleState: 0x18,
        close: 0x48
    }
}; */
// Test HID

// NEW
// const WINDOW_URL = 'https://petermcc0807.github.io/launcher/launcher.html';
// const WINDOW_URL = 'http://192.168.0.19:10240/launcher/launcher.html';
const WINDOW_URL = 'launcher/launcher.html';
// NEW

const WINDOW_REFOCUSREMOVE_TIMEOUT = 100;

let isChromeOS = false;

let launcherWindow = null;
let hidDevice = null;

// Test HID
// let leftButtonPressed; let rightButtonPressed;
// Test HID

const options =
{
    url: WINDOW_URL,

    type: 'popup',
    state: 'normal',
    focused: true,

    left: 0,
    top: 0,
    // TEMPORARY
    width: 1,
    height: 1
    // TEMPORARY
};

chrome.windows.create(options, (window) =>
{
    launcherWindow = window;

    /* const options = { state: 'minimized' };

    chrome.windows.update(launcherWindow.id, options, (window) =>
    {
        // Do something
    }); */
});

chrome.windows.onFocusChanged.addListener((windowId) =>
{
    // TODO: see [1]
});

chrome.windows.onRemoved.addListener((windowId) =>
{
    if ((launcherWindow !== null) && (launcherWindow.id === windowId))
        launcherWindow = null;
});

navigator.hid.addEventListener('connect', ({ device }) =>
{
    const productName = device.productName;

    console.log(`navigator.hid.on(connect): Device '${ productName }' connected`);

    // Do something
});

navigator.hid.addEventListener('disconnect', async ({ device }) =>
{
    const productName = device.productName;

    console.log(`navigator.hid.on(disconnect): Device '${ productName }' disconnected`);

    try
    {
        if (device.opened === true)
        {
            await device.close();

            console.log(`navigator.hid.on(disconnect): Device '${ productName }' closed`);
        }
    }

    catch (exception) { }

    if ((hidDevice !== null) && ((hidDevice.vendorId === device.vendorId) && (hidDevice.productId === device.productId)))
        hidDevice = null;
});

// NEW (0.0.41)
const intervalId = setInterval(async () =>
{
    console.log(`setInterval(() => { }): now=${ Date.now() }`);

    if (hidDevice !== null)
    {
        // AP10 HID
        const reportId = 0x04;

        const bytes = new Uint8Array([ 0x02, 0x27 ]);

        await hidDevice.sendReport(reportId, bytes);

        console.log(`setInterval(() => { }): Keep alive HID report sent`);
        // AP10 HID

        // Do something
    }
}, TIMER_INTERVAL);
// NEW (0.0.41)

// NEW (0.0.41)
chrome.alarms.create({ periodInMinutes: (ALARM_FREQUENCY_SECONDS / 60.0) });

chrome.alarms.onAlarm.addListener(async (alarm) =>
{
    console.log(`chrome.alarms.onAlarm(): now=${ Date.now() }`);

    const timestamp = Date.now();

    const url = `http://100.115.92.2:8080/api/ping?timestamp=${ timestamp }`;

    console.log(`chrome.alarms.onAlarm(): pinging ChromeOS Android Bridge; url=${ url }`);

    const abortController = new AbortController();

    const options = { method: 'get', signal: abortController.signal };

    const timeoutId = setTimeout(() =>
    {
        abortController.abort();
    }, CHROMEOSANDROIDBRIDGE_TIMEOUT);

    try
    {
        const response = await fetch(url, options);

        clearTimeout(timeoutId);

        if (response.status === 200)
        {
            const json = await response.json();

            console.log(`chrome.alarms.onAlarm(): pinged; response.json=${ JSON.stringify(json) }`);

            // Do something
        }
        else
        {
            console.log('chrome.alarms.onAlarm(): could not ping; error');

            // Do something
        }
    }

    catch (exception)
    {
        console.log('chrome.alarms.onAlarm(): could not ping; exception');

        clearTimeout(timeoutId);

        // Do something
    }
});
// NEW (0.0.41)

// NEW
const handleLauncherMessage = (listener, request, sender, sendResponse) =>
{
    if (request.type === 'load')
    {
        const options =
        {
            left: 0,
            top: (request.data.availHeight - request.data.height),
            width: request.data.width,
            height: request.data.height
        };

        console.log(`chrome.runtime.${ listener }(request.type=load): left=${ options.left }, top=${ options.top }, width=${ options.width }, height=${ options.height }`);

        isChromeOS = request.data.isChromeOS;

        console.log(`chrome.runtime.${ listener }(request.type=load): isChromeOS=${ isChromeOS }`);

        chrome.windows.update(launcherWindow.id, options, (window) =>
        {
            const options = { state: 'minimized' };

            chrome.windows.update(launcherWindow.id, options, (window) =>
            {
                // Do something
            });
        });

        sendResponse({ sender: 'background', type: 'response', data: { } });
    }
    else if (request.type === 'open')
    {
        const options = { state: 'minimized' };

        chrome.windows.update(launcherWindow.id, options, (window) =>
        {
            // Do something
        });

        sendResponse({ sender: 'background', type: 'response', data: { } });
    }
    else if (request.type === 'refocus')
    {
        if (isChromeOS === true)
        {
            const options =
            {
                url: '',

                type: 'popup',
                state: 'normal',
                focused: true,

                left: 0,
                top: 0,
                // TEMPORARY
                width: 1,
                height: 1
                // TEMPORARY
            };

            chrome.windows.create(options, (window) =>
            {
                const timeoutId = setTimeout(() =>
                {
                    chrome.windows.remove(window.id, (_window) =>
                    {
                        // Do something
                    });
                }, WINDOW_REFOCUSREMOVE_TIMEOUT);
            });
        }

        sendResponse({ sender: 'background', type: 'response', data: { } });
    }
    else if (request.type === 'close')
    {
        // Do something

        sendResponse({ sender: 'background', type: 'response', data: { } });
    }
    else { }
};

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) =>
{
    console.log('chrome.runtime.onMessageExternal()');

    if (request.sender === 'launcher')
        handleLauncherMessage('onMessageExternal', request, sender, sendResponse);

    return true;
});
// NEW

chrome.runtime.onMessage.addListener((request, sender, sendResponse) =>
{
    console.log('chrome.runtime.onMessage()');

    if (request.sender === 'launcher')
        handleLauncherMessage('onMessage', request, sender, sendResponse);
    else if (request.sender === 'page')
    {
        if (request.type === 'openDevice')
        {
            console.log('chrome.runtime.onMessage(request.type=openDevice)');

            // NOTE : see [1]

            (async () =>
            {
                const devices = await navigator.hid.getDevices();

                const device = devices[request.data.index];

                if (device.opened === false)
                {
                    try
                    {
                        await device.open();

                        const productName = device.productName;

                        console.log(`chrome.runtime.onMessage(request.type=openDevice): Device '${ productName }' opened`);
                    }

                    catch (exception) { }

                    if (device.opened === true)
                    {
                        device.addEventListener('inputreport', async (event) =>
                        {
                            // TODO: see [1]

                            const { data, device, reportId } = event;

                            const bytes = new Uint8Array(data.buffer);

                            // AP10 HID
                            const isFlameButton = bytes[1] === 0x20;

                            if ((reportId === 0x04) && (isFlameButton === true))
                            {
                                const byte = bytes[2];

                                if (byte === 0)
                                {
                                    console.log('device.on(inputreport): Flame button released');

                                    // Do something
                                }
                                else if (byte === 1)
                                {
                                    console.log('device.on(inputreport): Flame button pressed');

                                    if (launcherWindow !== null)
                                    {
                                        chrome.windows.get(launcherWindow.id, (window) =>
                                        {
                                            if (window.state === 'minimized')
                                            {
                                                const options = { state: 'normal', focused: true };

                                                chrome.windows.update(launcherWindow.id, options, (window) =>
                                                {
                                                    // Do something
                                                });
                                            }
                                            else if (window.state === 'normal')
                                            {
                                                if (window.focused === true)
                                                    if (isChromeOS === true)
                                                    {
                                                        const options =
                                                        {
                                                            url: '',

                                                            type: 'popup',
                                                            state: 'normal',
                                                            focused: true,

                                                            left: 0,
                                                            top: 0,
                                                            // TEMPORARY
                                                            width: 1,
                                                            height: 1
                                                            // TEMPORARY
                                                        };

                                                        chrome.windows.create(options, (window) =>
                                                        {
                                                            const options = { state: 'minimized' };

                                                            chrome.windows.update(launcherWindow.id, options, (_window) =>
                                                            {
                                                                const timeoutId = setTimeout(() =>
                                                                {
                                                                    chrome.windows.remove(window.id, (_window) =>
                                                                    {
                                                                        // Do something
                                                                    });
                                                                }, WINDOW_REFOCUSREMOVE_TIMEOUT);
                                                            });
                                                        });
                                                    }
                                                    else
                                                    {
                                                        const options = { state: 'minimized' };

                                                        chrome.windows.update(launcherWindow.id, options, (window) =>
                                                        {
                                                            // Do something
                                                        });
                                                    }
                                                else
                                                {
                                                    const options = { focused: true };

                                                    chrome.windows.update(launcherWindow.id, options, (window) =>
                                                    {
                                                        // Do something
                                                    });
                                                }
                                            }
                                            else { }
                                        });
                                    }
                                    else
                                    {
                                        const options =
                                        {
                                            url: WINDOW_URL,

                                            type: 'popup',
                                            state: 'normal',
                                            focused: true,

                                            left: 0,
                                            top: 0,
                                            // TEMPORARY
                                            width: 1,
                                            height: 1
                                            // TEMPORARY
                                        };

                                        chrome.windows.create(options, (window) =>
                                        {
                                            launcherWindow = window;

                                            // const options = { state: 'minimized' };
                                            //
                                            // chrome.windows.update(launcherWindow.id, options, (window) =>
                                            // {
                                            //     // Do something
                                            // });
                                        });
                                    }
                                }
                                else { }
                            }
                            // AP10 HID

                            // Test HID
                            /* const byte = bytes[BUTTONS.byteIndex];

                            if (leftButtonPressed === undefined)
                            {
                                if (byte === BUTTONS.byteValues.none)
                                    leftButtonPressed = false;
                                else if (byte === BUTTONS.byteValues.toggleState)
                                    leftButtonPressed = true;
                                else { }
                            }
                            else
                            {
                                if (byte === BUTTONS.byteValues.none)
                                    leftButtonPressed = false;
                                else if (byte === BUTTONS.byteValues.toggleState)
                                {
                                    if (leftButtonPressed === false)
                                    {
                                        console.log('device.on(inputreport): Toggle State button pressed');

                                        if (launcherWindow !== null)
                                        {
                                            chrome.windows.get(launcherWindow.id, (window) =>
                                            {
                                                if (window.state === 'minimized')
                                                {
                                                    const options = { state: 'normal', focused: true };

                                                    chrome.windows.update(launcherWindow.id, options, (window) =>
                                                    {
                                                        // Do something
                                                    });
                                                }
                                                else if (window.state === 'normal')
                                                {
                                                    if (window.focused === true)
                                                        if (isChromeOS === true)
                                                        {
                                                            const options =
                                                            {
                                                                url: '',

                                                                type: 'popup',
                                                                state: 'normal',
                                                                focused: true,

                                                                left: 0,
                                                                top: 0,
                                                                // TEMPORARY
                                                                width: 1,
                                                                height: 1
                                                                // TEMPORARY
                                                            };

                                                            chrome.windows.create(options, (window) =>
                                                            {
                                                                const options = { state: 'minimized' };

                                                                chrome.windows.update(launcherWindow.id, options, (_window) =>
                                                                {
                                                                    const timeoutId = setTimeout(() =>
                                                                    {
                                                                        chrome.windows.remove(window.id, (_window) =>
                                                                        {
                                                                            // Do something
                                                                        });
                                                                    }, WINDOW_REFOCUSREMOVE_TIMEOUT);
                                                                });
                                                            });
                                                        }
                                                        else
                                                        {
                                                            const options = { state: 'minimized' };

                                                            chrome.windows.update(launcherWindow.id, options, (window) =>
                                                            {
                                                                // Do something
                                                            });
                                                        }
                                                    else
                                                    {
                                                        const options = { focused: true };

                                                        chrome.windows.update(launcherWindow.id, options, (window) =>
                                                        {
                                                            // Do something
                                                        });
                                                    }
                                                }
                                                else { }
                                            });
                                        }
                                        else
                                        {
                                            const options =
                                            {
                                                url: WINDOW_URL,

                                                type: 'popup',
                                                state: 'normal',
                                                focused: true,

                                                left: 0,
                                                top: 0,
                                                // TEMPORARY
                                                width: 1,
                                                height: 1
                                                // TEMPORARY
                                            };

                                            chrome.windows.create(options, (window) =>
                                            {
                                                launcherWindow = window;

                                                // const options = { state: 'minimized' };
                                                //
                                                // chrome.windows.update(launcherWindow.id, options, (window) =>
                                                // {
                                                //     // Do something
                                                // });
                                            });
                                        }
                                    }

                                    leftButtonPressed = true;
                                }
                                else { }
                            }

                            if (rightButtonPressed === undefined)
                            {
                                if (byte === BUTTONS.byteValues.none)
                                    rightButtonPressed = false;
                                else if (byte === BUTTONS.byteValues.close)
                                    rightButtonPressed = true;
                                else { }
                            }
                            else
                            {
                                if (byte === BUTTONS.byteValues.none)
                                    rightButtonPressed = false;
                                else if (byte === BUTTONS.byteValues.close)
                                {
                                    if (rightButtonPressed === false)
                                    {
                                        console.log('device.on(inputreport): Close button pressed');

                                        if (launcherWindow !== null)
                                        {
                                            chrome.windows.remove(launcherWindow.id, (window) =>
                                            {
                                                // Do something
                                            });
                                        }
                                    }

                                    rightButtonPressed = true;
                                }
                                else { }
                            } */
                            // Test HID
                        });

                        hidDevice = device;
                    }
                }

                sendResponse({ sender: 'background', type: 'response', data: { } });
            })();
        }
        else { }
    }
    else { }

    return true;
});
